#!/usr/bin/php -q
<?php

if (function_exists('pcntl_signal')) {
    pcntl_signal(SIGHUP, SIG_IGN);
}

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

require_once 'AGI.Class.php';
require_once 'AGI_AsteriskManager.Class.php';
require_once 'AuthenticateAgi.php';
require_once 'CalcAgi.php';
require_once 'CallbackAgi.php';
require_once 'DidAgi.php';
require_once 'IvrAgi.php';
require_once 'MassiveCall.php';
require_once 'PickupAgi.php';
require_once 'PortabilidadeAgi.php';
require_once 'PortalDeVozAgi.php';
require_once 'QueueAgi.php';
require_once 'SearchTariff.php';
require_once 'SipCallAgi.php';
require_once 'SipTransferAgi.php';
require_once 'StandardCallAgi.php';
require_once 'Magnus.php';
require_once '/var/www/html/mbilling/protected/components/AsteriskAccess.php';

$agi     = new AGI();
$MAGNUS  = new Magnus();
$CalcAgi = new CalcAgi();
//$agi->verboseLevel = 1;

$agi->verbose("Start MBilling AGI", 20);

/*Set Server Details Below*/
$servername = "localhost";
$username = "root";
$password = "M4MqoAlxGkFdE16n";
$dbname = "mbilling";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

/*Get Row Count*/
$sql_a = "SELECT COUNT(*) AS name FROM pkg_callerid";
$result_a = $conn->query($sql_a);
$row_a = $result_a->fetch_object()->name;
echo "\n\n# of rows: {$row_a}\n\n";

$rnd=rand(1,$row_a);
echo "Rand is: {$rnd}\n\n";
$sql_b = "SELECT cid FROM pkg_callerid where name='$rnd'";
$result_b = $conn->query($sql_b);
$row_b = $result_b->fetch_object()->cid;
echo "Phone Number Selected: {$row_b}\n\n\n";
  
$agi->set_callerid($row_b);
?>

reference code

$agi->verbose("Set CallerID", 10);

$con = new mysqli("localhost", "root", "M4MqoAlxGkFdE16n", "mbilling");

$sql = "SELECT COUNT(*) AS name FROM pkg_callerid";
$count = $con->query($sql)->fetch_object()->name;

$rnd = rand(1,$count);
$sql = "SELECT cid FROM pkg_callerid where name = '$rnd' LIMIT 1";
$callerid = $con->query($sql)->fetch_object()->cid;
  
$agi->set_callerid($callerid);