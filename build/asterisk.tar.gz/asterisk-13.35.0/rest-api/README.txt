<!-- Written in -*- Markdown -*- -->

This directory contains the specification for the Asterisk RESTful
API. The API is documented using Swagger[1]. This is used to not only
generate executable documentation pages for the API, but also to
generate a lot of the boilerplate necessary for implementing the API
with Asterisk's HTTP server.

 [1]: http://swagger.wordnik.com/
