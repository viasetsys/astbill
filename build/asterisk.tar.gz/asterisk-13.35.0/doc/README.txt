The vast majority of the Asterisk project documentation has been moved to the
project wiki:

    https://wiki.asterisk.org/

Asterisk release tarballs contain an export of the wiki in PDF and plain text
form, which you can find in:

    doc/AST.pdf
    doc/AST.txt

Asterisk uses the Doxygen documentation software.  Run "make progdocs" and open
the resulting documentation index at doc/api/index.html in a webbrowser or copy
the directory to a directory served by a webserver for remote access.
